# 🧮 Easy Math Tutor  
**Samsung Innovation Campus (SIC) Project**  

## 📌 Project Overview  
**Easy Math Tutor** is an **interactive math learning platform** designed to make mathematics **simple, engaging, and personalized**.  
It helps students **practice math problems**, **get AI-powered step-by-step explanations**, **track their progress**, and **download professional PDF markcards**.  
The project is developed as part of the **Samsung Innovation Campus (SIC)** initiative.

---

## 🎯 Objective  
- To build a **user-friendly platform** for practicing and understanding mathematics.  
- To provide **step-by-step solutions** using **SymPy** and **AI-powered explanations** via **LLaMA**.  
- To **generate quizzes dynamically** based on student level and difficulty.  
- To **track performance** and allow students to download **personalized markcards**.

---

## 🧠 Real-World Problem Solved  
- Students often **struggle with understanding math concepts**.  
- Existing calculators **only provide final answers** but not **step-by-step solutions**.  
- Teachers require **tools to assess performance** and **analyze student progress**.  

**Easy Math Tutor** solves this by:  
- Generating **personalized quizzes** for practice.  
- Providing **deterministic and AI-powered explanations**.  
- Generating **professional markcards** after each test.  
- Tracking student performance over time.

---

## 🚀 Features  
✅ **Dynamic Quiz Generation** → Generates random questions based on **level, subject, and difficulty**  
✅ **Step-by-Step Explanations** → Uses **SymPy** and **LLaMA (Ollama)** for solving and explaining problems  
✅ **Smart Calculator** → Solves expressions & equations with detailed explanations  
✅ **Professional PDF Markcard** → Automatically generates a markcard after every quiz  
✅ **Dashboard Analytics** → Tracks attempts, scores, and performance trends  
✅ **Text-to-Speech (TTS)** → Reads out questions aloud for better accessibility  
✅ **Interactive Notepad** → Built-in rough work space inside the app  

---

## 🛠️ Technologies & Models Used  

| **Technology / Model**| **Purpose**                                | **Type**                |
|-----------------------|--------------------------------------------|-------------------------|
| **Python**            | Core programming language                  | Development Language    |
| **Streamlit**         | Building the interactive UI                | Web Framework           |
| **SymPy**             | Deterministic equation solving             | Mathematical Solver     |
| **LLaMA via Ollama**  | AI-powered natural language explanations   | AI Model                |
| **FPDF2**             | Generates professional markcards           | PDF Generation Tool     |
| **JSON**              | Stores quiz history & performance          | Lightweight Database    |
| **Pandas**            | Dashboard analytics & performance tracking | Data Analysis           |

---

## 🗂️ Project Structure  

